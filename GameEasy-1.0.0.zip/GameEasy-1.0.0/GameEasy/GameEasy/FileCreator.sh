#!/bin/bash

info() {
  echo -e "\033[33m$1\033[0m"
}

error() {
  echo -e "\033[31m$1\033[0m"
}

success() {
  echo -e "\033[32m$1\033[0m"
}

exit_on_error() {
  local error_message="$1"
  local error_code="$2"
  error "$error_message"
  echo "Error code: $error_code"
  exit 1
}

loading_screen() {
  clear
  echo -e "\033[1;36m"
  echo "**************************************"
  echo "*                                    *"
  echo "*              GameEasy              *"
  echo "*                                    *"
  echo "*  Copyright (c) 2024. No modification*"
  echo "*  for personal or commercial use.   *"
  echo "*                                    *"
  echo "**************************************"
  echo -e "\033[0m"
  sleep 2
  echo -e "\033[1;33mLoading...\033[0m"
  sleep 1
  echo -e "\033[1;33mPlease wait...\033[0m"
  sleep 1
}

info "Enter the game's name:"
read -r GAME_NAME

info "Enter the folder where the game is located:"
read -r GAME_FOLDER

GAME_FOLDER=$(eval echo "$GAME_FOLDER")
if [ ! -d "$GAME_FOLDER" ]; then
  exit_on_error "The specified folder does not exist." "ERR001"
fi

info "Select the .exe file to use:"
mapfile -t EXE_FILES < <(find "$GAME_FOLDER" -maxdepth 1 -type f -iname "*.exe")
if [ ${#EXE_FILES[@]} -eq 0 ]; then
  exit_on_error "No .exe files found in the specified folder." "ERR002"
fi

select EXE_FILE in "${EXE_FILES[@]}"; do
  if [ -n "$EXE_FILE" ]; then
    break
  else
    error "Invalid selection. Please try again."
  fi
done

SCRIPT_DIR=$(pwd)
GAME_DIR="$SCRIPT_DIR/$GAME_NAME"
mkdir -p "$GAME_DIR" || exit_on_error "Failed to create game directory." "ERR003"

cp "$EXE_FILE" "$GAME_DIR/" || exit_on_error "Failed to copy .exe file." "ERR004"

info "Copying necessary files and folders..."
find "$GAME_FOLDER" -maxdepth 1 -type f \( -iname "*.dll" -o -iname "*.ini" -o -iname "*.cfg" -o -iname "*.txt" \) -exec cp {} "$GAME_DIR/" \; || exit_on_error "Failed to copy necessary files." "ERR005"

RELEVANT_FOLDERS=("MonoBleedingEdge" "*_Data" "Plugins" "StreamingAssets" "Mods")
for folder in "${RELEVANT_FOLDERS[@]}"; do
  find "$GAME_FOLDER" -maxdepth 1 -type d -iname "$folder" -exec cp -r {} "$GAME_DIR/" \; || true
done

FILES_TXT="$GAME_DIR/Files.txt"
find "$GAME_DIR" -mindepth 1 -exec basename {} \; > "$FILES_TXT" || exit_on_error "Failed to update Files.txt." "ERR006"

RUNNER_SCRIPT="$GAME_DIR/$GAME_NAME.sh"
cat <<EOL > "$RUNNER_SCRIPT"
#!/bin/bash

info() {
  echo -e "\033[33m\$1\033[0m"
}

loading_screen() {
  clear
  echo -e "\033[1;36m"
  echo "**************************************"
  echo "*                                    *"
  echo "*              GameEasy              *"
  echo "*                                    *"
  echo "*  Copyright (c) 2024. No modification*"
  echo "*  for personal or commercial use.   *"
  echo "*                                    *"
  echo "**************************************"
  echo -e "\033[0m"
  sleep 2
  echo -e "\033[1;33mLoading...\033[0m"
  sleep 1
  echo -e "\033[1;33mPlease wait...\033[0m"
  sleep 1
}

loading_screen

info "Launching $GAME_NAME... Please wait..."

wine "\$PWD/${EXE_FILE##*/}"
EOL

chmod +x "$RUNNER_SCRIPT" || exit_on_error "Failed to make the runner script executable." "ERR007"

success "$GAME_NAME setup is complete. Use the $GAME_NAME.sh script in the $GAME_DIR folder to launch the game."

